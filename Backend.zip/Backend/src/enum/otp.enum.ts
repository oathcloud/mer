export enum OTPTYPEENUM {
    VERIFY = 'Verifiy',
    FORGOT = 'Forgot',
}
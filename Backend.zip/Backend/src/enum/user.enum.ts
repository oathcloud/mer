export enum UserRoleENUM {
    USER = "User",
    ADMIN = "Admin",
}
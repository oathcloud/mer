export enum NETWORKTYPEENUM {
    EVM = 'EVM',
    BTC = 'BTC',
    TRON = 'TRON',
}